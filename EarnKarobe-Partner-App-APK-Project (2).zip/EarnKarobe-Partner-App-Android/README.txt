==========================================================
EARNKAROBE PARTNER APP - NATIVE ANDROID APK SOURCE PROJECT
==========================================================

Package ID  : com.earnkarobe.partner
App Name    : EarnKarobe Partner
Mode        : 100% Embedded Partner App (ZERO Redirect Notice!)
Console Lock: Partner Console is disabled inside this APK
Backend Sync: https://ais-pre-tp4y4jpdscqjaeguaktict-47707355822.asia-southeast1.run.app

----------------------------------------------------------
WHY THIS FIXES THE "REDIRECT NOTICE" SCREEN
----------------------------------------------------------
This Android project embeds your compiled Partner App directly
inside app/src/main/assets/www/ and loads it locally using
AndroidX WebViewAssetLoader. It NEVER triggers Google's
"Redirect Notice" screen, opens instantly inside the app, and
synchronizes all products, categories, leads, and payouts
live with your backend website API.

----------------------------------------------------------
HOW TO CHANGE YOUR BACKEND WEBSITE URL (OPTIONAL)
----------------------------------------------------------
If you deploy your EarnKarobe backend to your own domain
(e.g. https://api.yourdomain.com), open:
  app/src/main/assets/www/index.html
and update:
  window.__EARNKAROBE_API_BASE__ = "https://your-backend-url";

----------------------------------------------------------
HOW TO BUILD YOUR .APK FILE
----------------------------------------------------------
OPTION A: Android Studio
1. Extract this ZIP and open the folder in Android Studio.
2. Wait for Gradle Sync.
3. Click: Build -> Build Bundle(s) / APK(s) -> Build APK(s).

OPTION B: GitHub Actions (No Android Studio Needed)
1. Upload this extracted folder to a GitHub repository.
2. Open Actions -> "Build EarnKarobe Partner APK" -> Run workflow.
3. Download the .apk from Artifacts.
